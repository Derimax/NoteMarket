package code;

import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Query {

	private static Connection connection = null;
	private static String separate = "------------------------------------\n";
	
	public static boolean connect(String username, String psw) {

	  try {
			   Class.forName("com.mysql.cj.jdbc.Driver");
			   String url ="jdbc:mysql://127.0.0.1:3306/NoteMarket?useSSL=false&serverTimezone=UTC"; 
			   connection = DriverManager.getConnection(url,username,psw);
			   return true;
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  return false;  
	  }
	}
	
	public static String disconnect() {
		
		try {
			connection.close();
			return "Connessione chiusa correttamente.\n";
		} catch (SQLException e) {
			return "Chiusura connessione fallita.\n";
		}
	}
	
	public static boolean AggiungiAccountAcquirente(String username, String email, String nome, String cognome, String psw, String indirizzo, String date, long numTelefono, String numeroCarta, String scadenza, String intestatario) {
		try {
			String statement = "INSERT INTO account VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setString(1, username);
			query.setString(2, email);
			query.setString(3, nome);
			query.setString(4, cognome);
			query.setString(5, psw);
			query.setString(6, indirizzo);
			query.setDate(7, Date.valueOf(date));
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO acquirente VALUES(?)");
			query1.setString(1, username);
			query1.executeUpdate();
			query1.close();
			PreparedStatement query2 = connection.prepareStatement("INSERT INTO telefonoAccount VALUES(?, ?)");
			query2.setLong(1, numTelefono);
			query2.setString(2, username);
			query2.executeUpdate();
			query2.close();
			PreparedStatement query3 = connection.prepareStatement("INSERT INTO cartadicredito VALUES (?, ?, ?, ?)");
			query3.setString(1, numeroCarta);
			query3.setString(2, scadenza);
			query3.setString(3, intestatario);
			query3.setString(4, username);
			query3.executeUpdate();
			query3.close();
			return true;
			} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean AggiungiAccountVenditore(String username, String email, String nome, String cognome, String psw, String indirizzo, String date, long numTelefono) {
		try {
			String statement = "INSERT INTO account VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setString(1, username);
			query.setString(2, email);
			query.setString(3, nome);
			query.setString(4, cognome);
			query.setString(5, psw);
			query.setString(6, indirizzo);
			query.setDate(7, Date.valueOf(date));
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO venditore VALUES(?)");
			query1.setString(1, username);
			query1.executeUpdate();
			query1.close();
			PreparedStatement query2 = connection.prepareStatement("INSERT INTO telefonoAccount VALUES(?, ?)");
			query2.setLong(1, numTelefono);
			query2.setString(2, username);
			query2.executeUpdate();
			query2.close();
			return true;
			}catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciCartaCredito(String numeroCarta, String scadenza, String intestatario, String username) {
		try {
			String statement = "INSERT INTO cartadicredito VALUES (?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setString(1, numeroCarta);
			query.setString(2, scadenza);
			query.setString(3, intestatario);
			query.setString(4, username);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciAcquisto(String data, String usernameAcquirente, String numeroCarta, int idVideolezione) {
		try {
			String statement = "INSERT INTO Acquisto (codiceAppunti, data, usernameAcquirente, numeroCarta, usernameVenditore, idVideolezione)VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setNull(1, Types.INTEGER);
			query.setDate(2, Date.valueOf(data));
			query.setString(3, usernameAcquirente);
			query.setString(4, numeroCarta);
			query.setNull(5, Types.JAVA_OBJECT);
			query.setInt(6, idVideolezione);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciAcquisto(int codiceAppunti, String data, String usernameAcquirente, String numeroCarta, String usernameVenditore) {
		try {
			String statement = "INSERT INTO Acquisto (codiceAppunti, data, usernameAcquirente, numeroCarta, usernameVenditore, idVideolezione) VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setInt(1, codiceAppunti);
			query.setDate(2, Date.valueOf(data));
			query.setString(3, usernameAcquirente);
			query.setString(4, numeroCarta);
			query.setString(5, usernameVenditore);
			query.setNull(6, Types.INTEGER);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciAppuntiCartaceo(int codice, String usernameVenditore, String dataCaricamento, String categoria, float prezzo, String codiceFiscaleModeratore, int quantitaPagine, float costiSpedizione) {
		try {
			String statement = "INSERT INTO appunti VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setInt(1, codice);
			query.setString(2, usernameVenditore);
			query.setString(3, dataCaricamento);
			query.setString(4, categoria);
			query.setFloat(5, prezzo);
			query.setString(6, codiceFiscaleModeratore);
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Cartaceo VALUES (?, ?, ?, ?)");
			query1.setString(1, usernameVenditore);
			query1.setInt(2, codice);
			query1.setInt(3, quantitaPagine);
			query1.setFloat(4, costiSpedizione);
			query1.executeUpdate();
			query1.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciAppuntiDigitale(int codice, String usernameVenditore, String dataCaricamento, String categoria, float prezzo, String codiceFiscaleModeratore, int dimensione, String tipoDocumento) {
		try {
			String statement = "INSERT INTO appunti VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setInt(1, codice);
			query.setString(2, usernameVenditore);
			query.setString(3, dataCaricamento);
			query.setString(4, categoria);
			query.setFloat(5, prezzo);
			query.setString(6, codiceFiscaleModeratore);
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Digitale VALUES (?, ?, ?, ?)");
			query1.setString(1, usernameVenditore);
			query1.setInt(2, codice);
			query1.setInt(3, dimensione);
			query1.setString(4, tipoDocumento);
			query1.executeUpdate();
			query1.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciVideolezione(int id, String argomento, String nome, float durata, String codiceFiscaleTutor) {
		try {
			String statement = "INSERT INTO Videolezione VALUES(?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setInt(1, id);
			query.setString(2, argomento);
			query.setString(3, nome);
			query.setFloat(4, durata);
			query.setString(5, codiceFiscaleTutor);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciStaffTutor(String codiceFiscale, String nome, String cognome, String indirizzo, String data, long numTelefono, String materia) {
		try {
			String statement = "INSERT INTO staff VALUES(?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setString(1, codiceFiscale);
			query.setString(2, nome);
			query.setString(3, cognome);
			query.setString(4, indirizzo);
			query.setDate(5, Date.valueOf(data));
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Tutor VALUES(?)");
			query1.setString(1, codiceFiscale);
			query1.executeUpdate();
			query1.close();
			PreparedStatement query2 = connection.prepareStatement("INSERT INTO TelefonoStaff VALUES(?, ?)");
			query2.setLong(1, numTelefono);
			query2.setString(2, codiceFiscale);
			query2.executeUpdate();
			query2.close();
			
			Statement query5 = connection.createStatement();
			ResultSet result = query5.executeQuery("SELECT * FROM NoteMarket.specializzazione");
			
			while(result.next()) {
				String materia1 = result.getString(1);
				if(materia.equals(materia1)) {
					PreparedStatement query4 = connection.prepareStatement("INSERT INTO Possiede VALUES(?, ?)");
					query4.setString(1, materia);
					query4.setString(2, codiceFiscale);
					query4.executeUpdate();
					query4.close();
					return true;
				}
			}
			
			String sql1 = "INSERT INTO Specializzazione VALUES(?)";
			PreparedStatement query3 = connection.prepareStatement(sql1);
			query3.setString(1, materia);
			query3.executeUpdate();
			query3.close();
			PreparedStatement query4 = connection.prepareStatement("INSERT INTO Possiede VALUES(?, ?)");
			query4.setString(1, materia);
			query4.setString(2, codiceFiscale);
			query4.executeUpdate();
			query4.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static boolean InserisciStaffModeratore(String codiceFiscale, String nome, String cognome, String indirizzo, String data, long numTelefono) {
		try {
			String statement = "INSERT INTO staff VALUES(?, ?, ?, ?, ?)";
			PreparedStatement query = connection.prepareStatement(statement);
			query.setString(1, codiceFiscale);
			query.setString(2, nome);
			query.setString(3, cognome);
			query.setString(4, indirizzo);
			query.setDate(5, Date.valueOf(data));
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Moderatore VALUES(?)");
			query1.setString(1, codiceFiscale);
			query1.executeUpdate();
			query1.close();
			PreparedStatement query2 = connection.prepareStatement("INSERT INTO TelefonoStaff VALUES(?, ?)");
			query2.setLong(1, numTelefono);
			query2.setString(2, codiceFiscale);
			query2.executeUpdate();
			query2.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static ArrayList<String> StampaStaff(){
		ArrayList<String> staff = new ArrayList<String>();
		staff.add("Staff\n\n");
		try {
			
			Statement query = connection.createStatement();
			ResultSet result = query.executeQuery("SELECT * \r\n" + 
					"FROM NoteMarket.Staff");
			
			while(result.next()) {
				String codiceFiscale = result.getString(1);
				String nome = result.getString(2);
				String cognome = result.getString(3);
				String indirizzo = result.getString(4);
				String dataNascita = result.getString(5);
				String result1 = "Codice fiscale: " + codiceFiscale + "\nNome: " + nome + "\nCognome: " + cognome + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataNascita + "\nNumero di telefono: ";

				for(String g : numeriTelefonoStaff(codiceFiscale))
						result1 = result1.concat(g + ", ");
				
				result1 = result1.substring(0, result1.length() - 2);	
				result1 = result1.concat("\n" + separate);
				staff.add(result1);
			}
			
			staff.add("Risultati prodotti: " + (staff.size()-1) + "\n\n");
			
			result.close();
			query.close();
					
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return staff;
	}
	
	public static ArrayList<String> StampaStaffTutor(){
		ArrayList<String> staff = new ArrayList<String>();
		staff.add("Tutor\n\n");
		try {
			
			Statement query = connection.createStatement();
			ResultSet result = query.executeQuery("SELECT * FROM NoteMarket.Staff, NoteMarket.Tutor\r\n" + 
					"WHERE Tutor.codiceFiscale = Staff.codiceFiscale");
			
			while(result.next()) {
				String codiceFiscale = result.getString(1);
				String nome = result.getString(2);
				String cognome = result.getString(3);
				String indirizzo = result.getString(4);
				String dataNascita = result.getString(5);
				
				String result1 = "Codice fiscale: " + codiceFiscale + "\nNome: " + nome + "\nCognome: " + cognome + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataNascita + "\nNumero di telefono: ";

				for(String g : numeriTelefonoStaff(codiceFiscale))
						result1 = result1.concat(g + ", ");
				
				result1 = result1.substring(0, result1.length() - 2);
				
				result1 = result1.concat("\nSpecializzazioni: ");
				
				for(String g: stampaSpecializzazioni(codiceFiscale)) 
					result1 = result1.concat(g + ", ");
				
				result1 = result1.substring(0, result1.length() - 2);
				
				result1 = result1.concat("\n" + separate);
				staff.add(result1);
			}
			
			staff.add("Risultati prodotti: " + (staff.size()-1) + "\n\n");
			
			result.close();
			query.close();
					
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return staff;
	}

	private static ArrayList <String> stampaSpecializzazioni(String codiceFiscale) {
		ArrayList <String> result = new ArrayList <String> ();
		
		try {
			String sql = "SELECT *\r\n" + 
					"FROM NoteMarket.Possiede, NoteMarket.Staff\r\n" + 
					"WHERE Possiede.codiceFiscaleTutor = ? AND\r\n" + 
					"	Possiede.codiceFiscaleTutor = Staff.codiceFiscale";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, codiceFiscale);
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				result.add(result2.getString(1));
			}
							
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
	
	return result;
	}
	
	public static ArrayList<String> StampaStaffModeratore(){
		ArrayList<String> staff = new ArrayList<String>();
		staff.add("Moderatori\n\n");
		try {
			
			Statement query = connection.createStatement();
			ResultSet result = query.executeQuery("SELECT * FROM NoteMarket.Staff, NoteMarket.Moderatore\r\n" + 
					"WHERE Moderatore.codiceFiscale = Staff.codiceFiscale");
			
			while(result.next()) {
				String codiceFiscale = result.getString(1);
				String nome = result.getString(2);
				String cognome = result.getString(3);
				String indirizzo = result.getString(4);
				String dataNascita = result.getString(5);
				
				String result1 = "Codice fiscale: " + codiceFiscale + "\nNome: " + nome + "\nCognome: " + cognome + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataNascita + "\nNumero di telefono: ";

				for(String g : numeriTelefonoStaff(codiceFiscale))
						result1 = result1.concat(g + ", ");
				
				result1 = result1.substring(0, result1.length() - 2);	
				result1 = result1.concat("\n" + separate);
				staff.add(result1);
			}
			
			staff.add("Risultati prodotti: " + (staff.size()-1) + "\n\n");
			
			result.close();
			query.close();
					
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return staff;
	}
	
	public static ArrayList<String> StampaUnAccount(String username){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Account\n\n");
		try {
			String sql = "SELECT * \r\n" + 
					"FROM NoteMarket.Account\r\n" + 
					"WHERE Account.Username = ?";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, username);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				String username1 = result1.getString(1);
				String email = result1.getString(2);
				String nome = result1.getString(3);
				String cognome = result1.getString(4);
				String psw = result1.getString(5);
				String indirizzo = result1.getString(6);
				String dataDiNascita = result1.getString(7);
				String risultato = "Username: " + username1 + "\nEmail: " + email + "\nNome: " + nome + "\nCognome: " + cognome + "\nPassword: " + psw + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataDiNascita + "\nNumero di telefono: ";
				
				for(String g : numeriTelefonoAccount(username1))
					risultato = risultato.concat(g + ", ");
			
				risultato = risultato.substring(0, risultato.length() - 2);	
				risultato = risultato.concat("\n" + separate);
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> StampaAccount(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Account\n\n");
		try {
			String sql = "SELECT *\r\n" + 
					"FROM NoteMarket.Account";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				String username1 = result1.getString(1);
				String email = result1.getString(2);
				String nome = result1.getString(3);
				String cognome = result1.getString(4);
				String psw = result1.getString(5);
				String indirizzo = result1.getString(6);
				String dataDiNascita = result1.getString(7);
				String risultato = "Username: " + username1 + "\nEmail: " + email + "\nNome: " + nome + "\nCognome: " + cognome + "\nPassword: " + psw + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataDiNascita + "\nNumero di telefono: " ;
				
				for(String g : numeriTelefonoAccount(username1))
					risultato = risultato.concat(g + ", ");
			
				risultato = risultato.substring(0, risultato.length() - 2);	
				risultato = risultato.concat("\n" + separate);
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	private static ArrayList <String> stampaCarteDiCredito(String username) {
		ArrayList <String> result = new ArrayList <String> ();
		
		try {
			String sql = "SELECT * \r\n" +
					"FROM NoteMarket.CartaDiCredito, NoteMarket.Acquirente\r\n"+
					"WHERE Acquirente.username = ? AND CartaDiCredito.username = Acquirente.Username;\r\n";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, username);
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				result.add(result2.getString(1));
			}
							
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
	
	return result;
	}
	
	public static ArrayList<String> StampaAccountAcquirente(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Account acquirenti\n\n");
		try {
			String sql = "SELECT *\r\n" + 
					"FROM NoteMarket.Account, NoteMarket.Acquirente\r\n" + 
					"WHERE Acquirente.username = Account.username";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				String username1 = result1.getString(1);
				String email = result1.getString(2);
				String nome = result1.getString(3);
				String cognome = result1.getString(4);
				String psw = result1.getString(5);
				String indirizzo = result1.getString(6);
				String dataDiNascita = result1.getString(7);
				String risultato = "Username: " + username1 + "\nEmail: " + email + "\nNome: " + nome + "\nCognome: " + cognome + "\nPassword: " + psw + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataDiNascita + "\nNumero di telefono: ";

				for(String g : numeriTelefonoAccount(username1))
					risultato = risultato.concat(g + ", ");
			
				risultato = risultato.substring(0, risultato.length() - 2);	
				risultato = risultato.concat("\n");
				
				risultato = risultato + "Carta di credito: ";
				for(String g : stampaCarteDiCredito(username1)) 
					risultato = risultato.concat(g + ", ");
				
				risultato = risultato.substring(0, risultato.length() - 2);	
				risultato = risultato.concat("\n" + separate);
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	
	
	public static ArrayList<String> StampaAccountVenditore(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Account venditori\n\n");
		try {
			String sql = "SELECT *\r\n" + 
					"FROM NoteMarket.Account, NoteMarket.Venditore\r\n" + 
					"WHERE Venditore.username = Account.username";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				String username1 = result1.getString(1);
				String email = result1.getString(2);
				String nome = result1.getString(3);
				String cognome = result1.getString(4);
				String psw = result1.getString(5);
				String indirizzo = result1.getString(6);
				String dataDiNascita = result1.getString(7);
				String risultato = "Username: " + username1 + "\nEmail: " + email + "\nNome: " + nome + "\nCognome: " + cognome + "\nPassword: " + psw + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + dataDiNascita + "\nNumero di telefono: " ;

				for(String g : numeriTelefonoAccount(username1))
					risultato = risultato.concat(g + ", ");
			
				risultato = risultato.substring(0, risultato.length() - 2);	
				risultato = risultato.concat("\n" + separate);
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaAppunti(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Appunti\n\n");
		try {
			String sql = "SELECT * FROM NoteMarket.Appunti";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				String codice = result2.getString(1);
				String usernameVenditore = result2.getString(2);
				String dataCaricamento = result2.getString(3);
				String categoria = result2.getString(4);
				String prezzo = result2.getString(5);
				String codiceFiscaleModeratore = result2.getString(6);
				String risultato = "Codice: " + codice + "\nUsername venditore: " + usernameVenditore + "\nData caricamento: " + dataCaricamento + "\nCategoria: " + categoria + "\nPrezzo: " + prezzo + "\nCodice fiscale moderatore: " + codiceFiscaleModeratore + "\n" + separate;
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result2.close();
			query.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaAppuntiDigitali(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Appunti digitali\n\n");
		try {
			String sql = "SELECT * FROM NoteMarket.Appunti, NoteMarket.Digitale WHERE Appunti.codice = Digitale.codice";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				String codice = result2.getString(1);
				String usernameVenditore = result2.getString(2);
				String dataCaricamento = result2.getString(3);
				String categoria = result2.getString(4);
				String prezzo = result2.getString(5);
				String codiceFiscaleModeratore = result2.getString(6);
				String dimensione = result2.getString(9);
				String tipoDocumento = result2.getString(10);
				String risultato = "Codice: " + codice + "\nUsername venditore: " + usernameVenditore + "\nData caricamento: " + dataCaricamento + "\nCategoria: " + categoria + "\nPrezzo: " + prezzo + "\nCodice fiscale moderatore: " + codiceFiscaleModeratore + "\nDimensione: " + dimensione + "\nTipo documento: " + tipoDocumento + "\n" + separate;
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result2.close();
			query.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaAppuntiCartacei(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Appunti cartacei\n\n");
		try {
			String sql = "SELECT * FROM NoteMarket.Appunti, NoteMarket.Cartaceo WHERE Appunti.codice = Cartaceo.codice";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				String codice = result2.getString(1);
				String usernameVenditore = result2.getString(2);
				String dataCaricamento = result2.getString(3);
				String categoria = result2.getString(4);
				String prezzo = result2.getString(5);
				String codiceFiscaleModeratore = result2.getString(6);
				String quantitaPagine = result2.getString(9);
				String costoSpedizione = result2.getString(10);
				String risultato = "Codice: " + codice + "\nUsername venditore: " + usernameVenditore + "\nData caricamento: " + dataCaricamento + "\nCategoria: " + categoria + "\nPrezzo: " + prezzo + "\nCodice fiscale moderatore: " + codiceFiscaleModeratore + "\nQuantità pagine: " + quantitaPagine + "\nCosto spedizione: " + costoSpedizione + "\n" + separate;
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result2.close();
			query.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaVideolezioniTranneTutor(String materia){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Videolezioni\n\n");
		try {
			
			String sql = "SELECT * \r\n" + 
					"FROM NoteMarket.Videolezione\r\n" + 
					"WHERE NOT EXISTS(SELECT *\r\n" + 
					"			  FROM NoteMarket.Possiede, NoteMarket.Tutor, NoteMarket.Specializzazione\r\n" + 
					"              WHERE Possiede.Materia = ? AND\r\n" + 
					"                    Specializzazione.Materia = Possiede.Materia AND\r\n" + 
					"                    Tutor.codiceFiscale = Possiede.codiceFiscaleTutor AND\r\n" + 
					"                    Videolezione.codFiscTutor = Possiede.codiceFiscaleTutor)";
			
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, materia);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				String id = result1.getString(1);
				String argomento = result1.getString(2);
				String nome = result1.getString(3);
				float durata = result1.getFloat(4);
				String codFiscTutor = result1.getString(5);
				String risultato = "Id: " + id + "\nArgomento: " + argomento + "\nNome: " + nome + "\nDurata: " + durata + "\nCodice fiscale tutor: " + codFiscTutor + "\n" + separate;
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaAppuntiPrezzo(float prezzo){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Appunti\n\n");
		try {
			String sql = "SELECT * FROM NoteMarket.Appunti WHERE Appunti.prezzo < ?";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setFloat(1, prezzo);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				int codice = result1.getInt(1);
				String usernameVenditore = result1.getString(2);
				Date data = result1.getDate(3);
				String categoria = result1.getString(4);
				float prezzo1 = result1.getFloat(5);
				String codFiscaleModeratore = result1.getString(6);
				String result2 = "Codice: " + codice + "\nUsername venditore: " + usernameVenditore + "\nData: " + data + "\nCategoria: " + categoria + "\nPrezzo: " + prezzo1 + "\nCodice fiscale moderatore: " + codFiscaleModeratore + "\n" + separate;
				result.add(result2);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;

	}
	
	public static ArrayList<String> stampaCodiceSpedizione(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Codice acquisto\n\n");
		try {
			String sql = "  SELECT Acquisto.codice\r\n" +
					"		FROM NoteMarket.Cartaceo, NoteMarket.Acquisto, NoteMarket.Appunti\r\n" +
					"		WHERE costiSpedizione IS NULL AND\r\n" +
					"		Acquisto.codiceAppunti = Appunti.codice AND\r\n" +
					"		Appunti.codice = Cartaceo.codice";
			
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				int codice = result1.getInt(1);
				String result2 = "Codice: " + codice + "\n" + separate;
				result.add(result2);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			result1.close();
			query.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	public static ArrayList<String> stampaNumAcquisti(String acquirente){
		ArrayList<String> result = new ArrayList<String>();
		
		try {
			String sql = "SELECT COUNT(*) as NumAcquisti\r\n" + 
					"FROM NoteMarket.Account, NoteMarket.Acquisto, NoteMarket.Acquirente\r\n" + 
					"WHERE Account.Username = Acquirente.username AND Acquisto.usernameAcquirente = Acquirente.username AND Acquirente.username = ?\r\n" + 
					"HAVING COUNT(*) > 0";
			
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, acquirente);
			ResultSet result1 = query.executeQuery();
			
			while(result1.next()) {
				int numAcquisti = result1.getInt(1);
				String result22 = "Numero acquisti: " + numAcquisti + "\n" + separate;
				result.add(result22);
			}
			
			result.add("Risultati prodotti: " + result.size() + "\n\n");
			
			query.close();
			result1.close();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		
		return result;
	}
	
	public static ArrayList<String> stampaTutorLettera(String lettere){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Tutor che iniziano per: " + lettere + "\n\n");
		
		try {
			String sql = "SELECT Staff.*\r\n" + 
					"FROM NoteMarket.Staff, NoteMarket.Tutor\r\n" + 
					"WHERE Tutor.codiceFiscale = Staff.codiceFiscale AND Staff.cognome LIKE ?";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, lettere + "%");
			ResultSet result2 = query.executeQuery();
			
			while(result2.next()) {
				String codiceFiscale = result2.getString(1);
				String nome = result2.getString(2);
				String cognome = result2.getString(3);
				String indirizzo = result2.getString(4);
				String date = result2.getString(5);
				String risultato = "Codice Fiscale: " + codiceFiscale + "\nNome: " + nome + "\nCognome: " + cognome + "\nIndirizzo: " + indirizzo + "\nData di nascita: " + date + "\n" + separate;
				result.add(risultato);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			query.close();
			result2.close();
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		return result;
	}
	
	private static ArrayList <String> numeriTelefonoStaff(String codiceFiscale) {
		ArrayList <String> result = new ArrayList <String> ();
		
			try {
				String sql = "SELECT TelefonoStaff.numero\r\n" + 
						"FROM NoteMarket.TelefonoStaff, NoteMarket.Staff\r\n" + 
						"WHERE TelefonoStaff.codiceFiscaleStaff = ? AND\r\n" + 
						"	TelefonoStaff.codiceFiscaleStaff = Staff.codiceFiscale";
				PreparedStatement query = connection.prepareStatement(sql);
				query.setString(1, codiceFiscale);
				ResultSet result2 = query.executeQuery();
				
				while(result2.next()) {
					result.add(result2.getString(1));
				}
								
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			}
		
		return result;
	}
	
	private static ArrayList <String> numeriTelefonoAccount(String username) {
		ArrayList <String> result = new ArrayList <String> ();
		
			try {
				String sql = "SELECT TelefonoAccount.Numero\r\n" + 
						"FROM NoteMarket.Account, NoteMarket.TelefonoAccount\r\n" + 
						"WHERE TelefonOAccount.username = Account.username AND\r\n" + 
						"	Account.username = ?";
				PreparedStatement query = connection.prepareStatement(sql);
				query.setString(1, username);
				ResultSet result2 = query.executeQuery();
				
				while(result2.next()) {
					result.add(result2.getString(1));
				}
								
			} catch (Exception e) {
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
			}
		
		return result;
	}
	
	public static ArrayList<String> stampaMaxPrezzo(){
		ArrayList<String> result = new ArrayList<String>();
		result.add("Massimo\n\n");
		
		try {
			String sql = "SELECT *\r\n" + 
					"FROM NoteMarket.Appunti\r\n" + 
					"WHERE Appunti.Prezzo = (SELECT max(Appunti.Prezzo) FROM NoteMarket.Appunti)";
			PreparedStatement query = connection.prepareStatement(sql);
			ResultSet result22 = query.executeQuery();
			
			while(result22.next()) {
				String codice = result22.getString(1);
				String usernameVenditore = result22.getString(2);
				Date dataCaricamento = result22.getDate(3);
				String categoria = result22.getString(4);
				float prezzo = result22.getFloat(5);
				String codiceFiscaleModeratore = result22.getString(6);
				String result11 = "Codice: " + codice + "\nUsername venditore: " + usernameVenditore + "\nData caricamento: " + dataCaricamento + "\nCategoria: " + categoria + "\nPrezzo: " + prezzo + "\nCodice fiscale moderatore: " + codiceFiscaleModeratore + "\n" + separate;
				result.add(result11);
			}
			
			result.add("Risultati prodotti: " + (result.size()-1) + "\n\n");
			
			query.close();
			result22.close();
			
			
		} catch(Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
		}
		
		return result;
	}
	
	public static ArrayList<String> AcquistiIntervalloDate(Date i, Date f) {
		ArrayList<String> acquisti = new ArrayList<String> ();
        acquisti.add("Acquisti\n\n");
		
		try {
            if(i.equals(f)) {
            	String statement = "SELECT *\r\n" + 
                     	"FROM NoteMarket.Acquisto\r\n" + 
                     	"WHERE Acquisto.data = ?";
            	PreparedStatement query = connection.prepareStatement(statement);
            	query.setDate(1, i);
            	ResultSet result = query.executeQuery();
            	
            	while(result.next()) {
                	int codice = result.getInt(1);
                	String codiceAppunti = result.getString(2);
                	Date data = result.getDate(3);
                	String usernameAcquirente = result.getString(4);
                	long numeroCarta = result.getLong(5);
                	String usernameVenditore = result.getString(6);
                	String idVideolezione = result.getString(7);
                	String result111 = "Codice: " + codice + "\nCodice appunti: " + codiceAppunti + "\nData: " + data + "\nUsername acquirente: " + usernameAcquirente + "\nNumero carta: " + numeroCarta + "\nUsername venditore: " + usernameVenditore + "\nId video-lezione: " + idVideolezione + "\n" + separate;
                	acquisti.add(result111);
                	}
                 	
                	acquisti.add("Risultati prodotti: " + (acquisti.size()-1) + "\n\n");
                
                	query.close();
                	result.close();
            	
            } else {
            String statement = "SELECT *\r\n" + 
                         	"FROM NoteMarket.Acquisto\r\n" + 
                         	"WHERE Acquisto.data >= ? AND\r\n" + 
                         	"    Acquisto.data <= ?";
            PreparedStatement query = connection.prepareStatement(statement);
            query.setDate(1, i);
            query.setDate(2, f);
            ResultSet result = query.executeQuery();

            while(result.next()) {
            	int codice = result.getInt(1);
            	String codiceAppunti = result.getString(2);
            	Date data = result.getDate(3);
            	String usernameAcquirente = result.getString(4);
            	long numeroCarta = result.getLong(5);
            	String usernameVenditore = result.getString(6);
            	String idVideolezione = result.getString(7);
            	String result111 = "Codice: " + codice + "\nCodice appunti: " + codiceAppunti + "\nData: " + data + "\nUsername acquirente: " + usernameAcquirente + "\nNumero carta: " + numeroCarta + "\nUsername venditore: " + usernameVenditore + "\nId video-lezione: " + idVideolezione + "\n" + separate;
            	acquisti.add(result111);
            	}
             	
            	acquisti.add("Risultati prodotti: " + (acquisti.size()-1) + "\n\n");
            
            	query.close();
            	result.close();
            }
            
            
        } catch(Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
        }
        return acquisti;
    }
	
	public static boolean InserisciNumeroStaff(long numeroTelefono, String codiceFiscale) {
		
		try {
			String sql = "INSERT INTO TelefonoStaff VALUES(?, ?)";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setLong(1, numeroTelefono);
			query.setString(2, codiceFiscale);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
            return false;
		}
	}
	
	public static boolean InserisciNumeroAccount(long numeroTelefono, String username) {
		try {
			String sql = "INSERT INTO TelefonoAccount VALUES(?, ?)";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setLong(1, numeroTelefono);
			query.setString(2, username);
			query.executeUpdate();
			query.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
            return false;
		}
	}
	
	public static boolean InserisciTutorSpecializzazioneNuova(String materia, String codiceFiscaleTutor) {
		try {
			String sql = "INSERT INTO Specializzazione VALUES(?)";
			PreparedStatement query = connection.prepareStatement(sql);
			query.setString(1, materia);
			query.executeUpdate();
			query.close();
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Possiede VALUES(?, ?)");
			query1.setString(1, materia);
			query1.setString(2, codiceFiscaleTutor);
			query1.executeUpdate();
			query1.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
            return false;
		}
	}
	
	public static boolean InserisciTutorSpecializzazioneEsistente(String materia, String codiceFiscaleTutor) {
		try {
			PreparedStatement query1 = connection.prepareStatement("INSERT INTO Possiede VALUES(?, ?)");
			query1.setString(1, materia);
			query1.setString(2, codiceFiscaleTutor);
			query1.executeUpdate();
			query1.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Inserisci i dati correttamente!","Errore", JOptionPane.ERROR_MESSAGE);
            return false;
		}
	}
	
}
