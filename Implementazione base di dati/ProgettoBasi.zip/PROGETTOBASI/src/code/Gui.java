package code;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Date;
import java.util.ArrayList;

import javax.swing.*;

public class Gui extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static JFrame framePannello = new JFrame();
	private static JPasswordField passwordArea = new JPasswordField();
	private static JTextField usernameArea = new JTextField();

	public Gui(){
		super("Note Market");
		
		JTextArea result = new JTextArea();
		JScrollPane scroll = new JScrollPane(result);
		add(scroll, BorderLayout.CENTER);
		result.setEditable(false);
		
		JPanel pannelloQuery = new JPanel();
		pannelloQuery.setBorder(BorderFactory.createTitledBorder("Gestione"));
		JButton disconnect = new JButton("Disconnetti");
		disconnect.addActionListener(e -> {
			Query.disconnect();
			setVisible(false);
			framePannello.setVisible(true);
			passwordArea.setText("");
			usernameArea.setText("");
		});
		 
		JButton esegui = new JButton("Esegui");
		
		JComboBox<String> query = new JComboBox<String>();
		query.addItem("Inserimento di un account");
		query.addItem("Inserimento di un numero di telefono di un account");
		query.addItem("Inserimento di una nuova carta di credito");
		query.addItem("Inserimento di un nuovo acquisto");
		query.addItem("Inserimento di un nuovo appunto");
		query.addItem("Inserimento di una video-lezione");
		query.addItem("Inserimento di un membro dello staff");
		query.addItem("Inserimento di un numero di telefono di un membro dello staff");
		query.addItem("Inserimento di una specializzazione di un tutor");
		query.addItem("Stampa dei dati relativi ai membri dello staff");
		query.addItem("Stampa dei moderatori");
		query.addItem("Stampa dei tutor");
		query.addItem("Stampa dei dati relativi ad un account");
		query.addItem("Stampa gli acquisti in un determinato intervallo");
		query.addItem("Stampa degli account");
		query.addItem("Stampa degli acquirenti");
		query.addItem("Stampa dei venditori");
		query.addItem("Stampa dei dati relativi agli appunti");
		query.addItem("Stampa degli appunti digitali");
		query.addItem("Stampa degli appunti cartacei");
		query.addItem("Stampa tutte le video-lezioni, tranne dei tutor che insegnano una determinata materia");
		query.addItem("Stampa tutti gli appunti con prezzo inferiore ad una determinata cifra");
		query.addItem("Stampa del codice di tutti gli acquisti di appunti che non sono in formato digitale, la cui spedizione è gratis");
		query.addItem("Stampa numero acquisti di un account acquirente che ha effettuato almeno un acquisto");
		query.addItem("Stampa l’appunto con il maggior prezzo");
		query.addItem("Stampa la lista di Tutor il cui cognome inizia con una data lettera o stringa");
		
		esegui.addActionListener(e -> {
			String selected = (String) query.getSelectedItem();
			if(selected.equals("Inserimento di un account")) {
				setVisible(false);
				Object[] options = { "Venditore", "Acquirente"};
				int res = JOptionPane.showOptionDialog(getParent(), "Che tipo di account vuoi creare?", "Creazione account", JOptionPane.NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, null);
				
				if(res == 0) {
					JFrame frame = new JFrame();
					frame.setTitle("Inserimento di un account");
					JLabel username = new JLabel("Username:");
					JTextField usernameArea = new JTextField();
					JLabel email = new JLabel("Email:");
					JTextField emailArea = new JTextField();
					JLabel nome = new JLabel("Nome:");
					JTextField nomeArea = new JTextField();
					JLabel cognome = new JLabel("Cognome: ");
					JTextField cognomeArea = new JTextField();
					JLabel psw = new JLabel("Password:");
					JTextField pswArea = new JTextField();
					JLabel indirizzo = new JLabel("Indirizzo:");
					JTextField indirizzoArea = new JTextField();
					JLabel data = new JLabel("Data di nascita:");
					JTextField dataArea = new JTextField();
					JLabel numeroTelefono = new JLabel("Numero di telefono: ");
					JTextField numeroTelefonoArea = new JTextField();
				
				JPanel pannello = new JPanel();
				pannello.setLayout(new GridLayout(9,1));
				pannello.add(username);
				pannello.add(usernameArea);
				pannello.add(email);
				pannello.add(emailArea);
				pannello.add(nome);
				pannello.add(nomeArea);
				pannello.add(cognome);
				pannello.add(cognomeArea);
				pannello.add(psw);
				pannello.add(pswArea);
				pannello.add(indirizzo);
				pannello.add(indirizzoArea);
				pannello.add(data);
				pannello.add(dataArea);
				pannello.add(numeroTelefono);
				pannello.add(numeroTelefonoArea);
				
				JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(c -> {
						if(Query.AggiungiAccountVenditore(usernameArea.getText(), emailArea.getText(), nomeArea.getText(), cognomeArea.getText(), pswArea.getText(), indirizzoArea.getText(), dataArea.getText(), Long.parseLong(numeroTelefonoArea.getText()))) {
							frame.dispose();
							setVisible(true);
							JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(f -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				frame.add(pannello);
				frame.setLocationRelativeTo(getParent());
				frame.setSize(400, 400);
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				} else if(res == 1) {
					JFrame frame = new JFrame();
					frame.setTitle("Inserimento di un account");
					JLabel username = new JLabel("Username:");
					JTextField usernameArea = new JTextField();
					JLabel email = new JLabel("Email:");
					JTextField emailArea = new JTextField();
					JLabel nome = new JLabel("Nome:");
					JTextField nomeArea = new JTextField();
					JLabel cognome = new JLabel("Cognome: ");
					JTextField cognomeArea = new JTextField();
					JLabel psw = new JLabel("Password:");
					JTextField pswArea = new JTextField();
					JLabel indirizzo = new JLabel("Indirizzo:");
					JTextField indirizzoArea = new JTextField();
					JLabel data = new JLabel("Data di nascita:");
					JTextField dataArea = new JTextField();
					JLabel numeroTelefono = new JLabel("Numero di telefono: ");
					JTextField numeroTelefonoArea = new JTextField();
					JLabel numeroCarta = new JLabel("Numero carta di credito: ");
					JTextField numeroCartaArea = new JTextField();
					JLabel scadenza = new JLabel("Scadenza: ");
					JTextField scadenzaArea = new JTextField();
					
					JPanel pannello = new JPanel();
					pannello.setLayout(new GridLayout(11,1));
					pannello.add(username);
					pannello.add(usernameArea);
					pannello.add(email);
					pannello.add(emailArea);
					pannello.add(nome);
					pannello.add(nomeArea);
					pannello.add(cognome);
					pannello.add(cognomeArea);
					pannello.add(psw);
					pannello.add(pswArea);
					pannello.add(indirizzo);
					pannello.add(indirizzoArea);
					pannello.add(data);
					pannello.add(dataArea);
					pannello.add(numeroTelefono);
					pannello.add(numeroTelefonoArea);
					pannello.add(numeroCarta);
					pannello.add(numeroCartaArea);
					pannello.add(scadenza);
					pannello.add(scadenzaArea);
					
					
					JButton esegui1 = new JButton("Esegui");
					esegui1.addActionListener(c -> {
							if(Query.AggiungiAccountAcquirente(usernameArea.getText(), emailArea.getText(), nomeArea.getText(), cognomeArea.getText(), pswArea.getText(), indirizzoArea.getText(), dataArea.getText(), Long.parseLong(numeroTelefonoArea.getText()), numeroCartaArea.getText(), scadenzaArea.getText(), (nomeArea.getText() + " " + cognomeArea.getText()))) {
								frame.dispose();
								setVisible(true);
								JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
							} else ;
					});
					
					JButton back = new JButton("Indietro");
					back.addActionListener(f -> {
						frame.dispose();
						setVisible(true);
					});
					
					pannello.add(esegui1);
					pannello.add(back);
					frame.add(pannello);
					frame.setLocationRelativeTo(getParent());
					frame.setSize(400, 400);
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}
				
			} else if(selected.equals("Inserimento di una nuova carta di credito")) {
				setVisible(false);
				JFrame frame = new JFrame();
				frame.setTitle("Inserimento di una nuova carta di credito");
				JLabel numeroCarta = new JLabel("Numero carta:");
				JTextField numeroCartaArea = new JTextField();
				JLabel scadenza = new JLabel("Scadenza:");
				JTextField scadenzaArea = new JTextField();
				JLabel intestatario = new JLabel("Intestatario: ");
				JTextField intestatarioArea = new JTextField();
				JLabel username = new JLabel("Username: ");
				JTextField usernameArea = new JTextField();
				
				JPanel pannello = new JPanel();
				pannello.setLayout(new GridLayout(5, 1));
				pannello.add(numeroCarta);
				pannello.add(numeroCartaArea);
				pannello.add(scadenza);
				pannello.add(scadenzaArea);
				pannello.add(intestatario);
				pannello.add(intestatarioArea);
				pannello.add(username);
				pannello.add(usernameArea);
				
				JButton esegui3 = new JButton("Esegui");
				esegui3.addActionListener(l -> {
					if(Query.InserisciCartaCredito(numeroCartaArea.getText(), scadenzaArea.getText(), intestatarioArea.getText(), usernameArea.getText())) {
					frame.dispose();
					setVisible(true);
					JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
					} else ;
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui3);
				pannello.add(back);
				
				frame.add(pannello);
				
				frame.setVisible(true);
				frame.setLocationRelativeTo(getParent());
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(400, 400);
			} else if(selected.equals("Inserimento di un nuovo acquisto")) {
				setVisible(false);
				JFrame frame = new JFrame();
				Object[] options = { "Appunti", "Videolezione"};
				int res = JOptionPane.showOptionDialog(getParent(), "In cosa consiste la transazione?", "Acquisto", JOptionPane.NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, null);
				if(res == 1) {
					frame.setTitle("Acquisto video-lezione");
					JLabel data = new JLabel("Data: ");
					JTextField dataArea = new JTextField();
					JLabel usernameAcquirente = new JLabel("Username Acquirente: ");
					JTextField usernameAcquirenteArea = new JTextField();
					JLabel numeroCarta = new JLabel("Numero carta: ");
					JTextField numeroCartaArea = new JTextField();
					JLabel idVideoLezione = new JLabel("ID Videolezione: ");
					JTextField idVideoLezioneArea = new JTextField();
					
					JPanel pannello = new JPanel();
					pannello.setLayout(new GridLayout(5,1));
					pannello.add(data);
					pannello.add(dataArea);
					pannello.add(usernameAcquirente);
					pannello.add(usernameAcquirenteArea);
					pannello.add(numeroCarta);
					pannello.add(numeroCartaArea);
					pannello.add(idVideoLezione);
					pannello.add(idVideoLezioneArea);
					
					
					JButton esegui5 = new JButton("Esegui");
					esegui5.addActionListener(l ->{
						if(Query.InserisciAcquisto(dataArea.getText(), usernameAcquirenteArea.getText(), numeroCartaArea.getText(), Integer.parseInt(idVideoLezioneArea.getText()))){
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
					});
					
					JButton back = new JButton("Indietro");
					back.addActionListener(d -> {
						frame.dispose();
						setVisible(true);
					});
					
					pannello.add(esegui5);
					pannello.add(back);
					
					frame.add(pannello);
					
					
				} else if(res == 0) {
					frame.setTitle("Acquisto appunti");
					JLabel codiceAppunti = new JLabel("Codice appunti: ");
					JTextField codiceAppuntiArea = new JTextField();
					JLabel data = new JLabel("Data: ");
					JTextField dataArea = new JTextField();
					JLabel usernameAcquirente = new JLabel("Username Acquirente: ");
					JTextField usernameAcquirenteArea = new JTextField();
					JLabel numeroCarta = new JLabel("Numero carta: ");
					JTextField numeroCartaArea = new JTextField();
					JLabel usernameVenditore = new JLabel("Username venditore: ");
					JTextField usernameVenditoreArea = new JTextField();
					
					
					JPanel pannello = new JPanel();
					pannello.setLayout(new GridLayout(6,1));
					pannello.add(codiceAppunti);
					pannello.add(codiceAppuntiArea);
					pannello.add(data);
					pannello.add(dataArea);
					pannello.add(usernameAcquirente);
					pannello.add(usernameAcquirenteArea);
					pannello.add(numeroCarta);
					pannello.add(numeroCartaArea);
					pannello.add(usernameVenditore);
					pannello.add(usernameVenditoreArea);
					
					JButton esegui1 = new JButton("Esegui");
					esegui1.addActionListener(l -> {
						if(Query.InserisciAcquisto(Integer.parseInt(codiceAppuntiArea.getText()), dataArea.getText(), usernameAcquirenteArea.getText(), numeroCartaArea.getText(), usernameVenditoreArea.getText())) {
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
					});
					
					JButton back = new JButton("Indietro");
					back.addActionListener(d -> {
						frame.dispose();
						setVisible(true);
					});
					
					pannello.add(esegui1);
					pannello.add(back);
					frame.add(pannello);
				}
				
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(400, 400);
				frame.setLocationRelativeTo(getParent());	
			} else if(selected.equals("Inserimento di un nuovo appunto")) {
				setVisible(false);
				Object[] options = { "Cartaceo", "Digitale"};
				int res = JOptionPane.showOptionDialog(getParent(), "Che tipo di appunto vuoi inserire?", "Inserisci appunti", JOptionPane.NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, null);
				
				if(res == 0) {
					JFrame frame = new JFrame();
					frame.setTitle("Inserimento di un nuovo appunto cartaceo");
					JLabel codice = new JLabel("Codice:");
					JTextField codiceArea = new JTextField();
					JLabel usernameVenditore = new JLabel("Username venditore: ");
					JTextField usernameVenditoreArea = new JTextField();
					JLabel dataCaricamento = new JLabel("Data caricamento: ");
					JTextField dataCaricamentoArea = new JTextField();
					JLabel categoria = new JLabel("Categoria: ");
					JTextField categoriaArea = new JTextField();
					JLabel prezzo = new JLabel("Prezzo: ");
					JTextField prezzoArea = new JTextField();
					JLabel codiceFiscaleModeratore = new JLabel("Codice fiscale moderatore: ");
					JTextField codiceFiscaleModeratoreArea = new JTextField();
					JLabel quantitaPagine = new JLabel("Quantità pagine: ");
					JTextField quantitaPagineArea = new JTextField();
					JLabel costiSpedizione = new JLabel("Costi spedizione: ");
					JTextField costiSpedizioneArea = new JTextField();
					
					JPanel pannello = new JPanel();
					pannello.setLayout(new GridLayout(9,1));
					pannello.add(codice);
					pannello.add(codiceArea);
					pannello.add(usernameVenditore);
					pannello.add(usernameVenditoreArea);
					pannello.add(dataCaricamento);
					pannello.add(dataCaricamentoArea);
					pannello.add(categoria);
					pannello.add(categoriaArea);
					pannello.add(prezzo);
					pannello.add(prezzoArea);
					pannello.add(codiceFiscaleModeratore);
					pannello.add(codiceFiscaleModeratoreArea);
					pannello.add(quantitaPagine);
					pannello.add(quantitaPagineArea);
					pannello.add(costiSpedizione);
					pannello.add(costiSpedizioneArea);
				
					JButton esegui1 = new JButton("Esegui");
					esegui1.addActionListener(l -> {
						if(Query.InserisciAppuntiCartaceo(Integer.parseInt(codiceArea.getText()), usernameVenditoreArea.getText(), dataCaricamentoArea.getText(), categoriaArea.getText(), Float.parseFloat(prezzoArea.getText()), codiceFiscaleModeratoreArea.getText(), Integer.parseInt(quantitaPagineArea.getText()), Float.parseFloat(costiSpedizioneArea.getText()))) {
							frame.dispose();
							setVisible(true);
							JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
							} else ;
					});
				
					JButton back = new JButton("Indietro");
					back.addActionListener(d -> {
						frame.dispose();
						setVisible(true);
					});
				
					pannello.add(esegui1);
					pannello.add(back);
				
					frame.add(pannello);
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setSize(400, 400);
					frame.setLocationRelativeTo(null);
					
					} else if(res == 1) {
						JFrame frame = new JFrame();
						frame.setTitle("Inserimento di un nuovo appunto digitale");
						JLabel codice = new JLabel("Codice:");
						JTextField codiceArea = new JTextField();
						JLabel usernameVenditore = new JLabel("Username venditore: ");
						JTextField usernameVenditoreArea = new JTextField();
						JLabel dataCaricamento = new JLabel("Data caricamento: ");
						JTextField dataCaricamentoArea = new JTextField();
						JLabel categoria = new JLabel("Categoria: ");
						JTextField categoriaArea = new JTextField();
						JLabel prezzo = new JLabel("Prezzo: ");
						JTextField prezzoArea = new JTextField();
						JLabel codiceFiscaleModeratore = new JLabel("Codice fiscale moderatore: ");
						JTextField codiceFiscaleModeratoreArea = new JTextField();
						JLabel dimensione = new JLabel("Dimensione: ");
						JTextField dimensioneArea = new JTextField();
						JLabel tipoDocumento = new JLabel("Tipo documento: ");
						JTextField tipoDocumentoArea = new JTextField();
						
						JPanel pannello = new JPanel();
						pannello.setLayout(new GridLayout(9,1));
						pannello.add(codice);
						pannello.add(codiceArea);
						pannello.add(usernameVenditore);
						pannello.add(usernameVenditoreArea);
						pannello.add(dataCaricamento);
						pannello.add(dataCaricamentoArea);
						pannello.add(categoria);
						pannello.add(categoriaArea);
						pannello.add(prezzo);
						pannello.add(prezzoArea);
						pannello.add(codiceFiscaleModeratore);
						pannello.add(codiceFiscaleModeratoreArea);
						pannello.add(dimensione);
						pannello.add(dimensioneArea);
						pannello.add(tipoDocumento);
						pannello.add(tipoDocumentoArea);
					
						JButton esegui1 = new JButton("Esegui");
						esegui1.addActionListener(l -> {
							if(Query.InserisciAppuntiDigitale(Integer.parseInt(codiceArea.getText()), usernameVenditoreArea.getText(), dataCaricamentoArea.getText(), categoriaArea.getText(), Float.parseFloat(prezzoArea.getText()), codiceFiscaleModeratoreArea.getText(), Integer.parseInt(dimensioneArea.getText()), tipoDocumentoArea.getText())) {
								frame.dispose();
								setVisible(true);
								JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
								} else ;
						});
					
						JButton back = new JButton("Indietro");
						back.addActionListener(d -> {
							frame.dispose();
							setVisible(true);
						});
					
						pannello.add(esegui1);
						pannello.add(back);
					
						frame.add(pannello);
						frame.setVisible(true);
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						frame.setSize(400, 400);
						frame.setLocationRelativeTo(null);
					}
			} else if(selected.equals("Inserimento di una video-lezione")) {
				setVisible(false);
				JFrame frame = new JFrame();
				frame.setTitle("Inserimento di una video-lezione");
				JLabel id = new JLabel("ID: ");
				JTextField idArea = new JTextField();
				JLabel argomento = new JLabel("Argomento: ");
				JTextField argomentoArea = new JTextField();
				JLabel nome = new JLabel("Nome: ");
				JTextField nomeArea = new JTextField();
				JLabel durata = new JLabel("Durata: ");
				JTextField durataArea = new JTextField();
				JLabel codiceFiscaleTutor = new JLabel("Codice fiscale tutor: ");
				JTextField codiceFiscaleTutorArea = new JTextField();
				
				JPanel pannello = new JPanel();
				pannello.setLayout(new GridLayout(6,1));
				pannello.add(id);
				pannello.add(idArea);
				pannello.add(argomento);
				pannello.add(argomentoArea);
				pannello.add(nome);
				pannello.add(nomeArea);
				pannello.add(durata);
				pannello.add(durataArea);
				pannello.add(codiceFiscaleTutor);
				pannello.add(codiceFiscaleTutorArea);
				
				JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(l -> {
					if(Query.InserisciVideolezione(Integer.parseInt(idArea.getText()), argomentoArea.getText(), nomeArea.getText(), Float.parseFloat(durataArea.getText()), codiceFiscaleTutorArea.getText())) {
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				
				frame.add(pannello);
				
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(400, 400);
				frame.setLocationRelativeTo(getParent());
			} else if(selected.equals("Inserimento di un membro dello staff")) {
				setVisible(false);
				Object[] options = { "Tutor", "Moderatore"};
				int res = JOptionPane.showOptionDialog(getParent(), "Che ruolo ha il membro dello staff?", "Scegli ruolo", JOptionPane.NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, null);
				
				JFrame frame = new JFrame();
				frame.setTitle("Inserimento di un membro dello staff");
				JPanel pannello = new JPanel();
				
				JLabel codiceFiscale = new JLabel("Codice fiscale: ");
				JTextField codiceFiscaleArea = new JTextField();
				JLabel nome = new JLabel("Nome: ");
				JTextField nomeArea = new JTextField();
				JLabel cognome = new JLabel("Cognome: ");
				JTextField cognomeArea = new JTextField();
				JLabel indirizzo = new JLabel("Indirizzo: ");
				JTextField indirizzoArea = new JTextField();
				JLabel data = new JLabel("Data: ");
				JTextField dataArea = new JTextField();
				JLabel numeroTelefono = new JLabel("Numero di telefono: ");
				JTextField numeroTelefonoArea = new JTextField();
				JLabel materia = new JLabel("Materia: ");
				JTextField materiaArea = new JTextField();
				
				if(res == 0) {
				pannello.setLayout(new GridLayout(8, 1));
				pannello.add(codiceFiscale);
				pannello.add(codiceFiscaleArea);
				pannello.add(nome);
				pannello.add(nomeArea);
				pannello.add(cognome);
				pannello.add(cognomeArea);
				pannello.add(indirizzo);
				pannello.add(indirizzoArea);
				pannello.add(data);
				pannello.add(dataArea);
				pannello.add(numeroTelefono);
				pannello.add(numeroTelefonoArea);
				pannello.add(materia);
				pannello.add(materiaArea);
				
				} else if(res == 1) {
					
					pannello.setLayout(new GridLayout(7, 1));
					pannello.add(codiceFiscale);
					pannello.add(codiceFiscaleArea);
					pannello.add(nome);
					pannello.add(nomeArea);
					pannello.add(cognome);
					pannello.add(cognomeArea);
					pannello.add(indirizzo);
					pannello.add(indirizzoArea);
					pannello.add(data);
					pannello.add(dataArea);
					pannello.add(numeroTelefono);
					pannello.add(numeroTelefonoArea);
					
					
				}
				
				JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(l -> {
					if(res == 0) {
					if(Query.InserisciStaffTutor(codiceFiscaleArea.getText(), nomeArea.getText(), cognomeArea.getText(), indirizzoArea.getText(), dataArea.getText(), Long.parseLong(numeroTelefonoArea.getText()), materiaArea.getText())) {
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
					} else if(res == 1) {
						if(Query.InserisciStaffModeratore(codiceFiscaleArea.getText(), nomeArea.getText(), cognomeArea.getText(), indirizzoArea.getText(), dataArea.getText(), Long.parseLong(numeroTelefonoArea.getText()))) {
							frame.dispose();
							setVisible(true);
							JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
							} else ;
					}
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				
				frame.add(pannello);
				
				
				frame.setVisible(true);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(400, 400);
				frame.setLocationRelativeTo(getParent());
				
				
			} else if(selected.equals("Stampa dei dati relativi ai membri dello staff")) {
				ArrayList<String> result1 = Query.StampaStaff();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono membri dello staff", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa dei dati relativi ad un account")) {
				String username = JOptionPane.showInputDialog("Inserisci il nome dell'account");
				ArrayList<String> risultato = Query.StampaUnAccount(username);
				if(risultato.size() > 2)
					for(String g : risultato)
						result.append(g);
				else 
					JOptionPane.showMessageDialog(null, "Utente non trovato", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa dei dati relativi agli appunti")) {
				ArrayList<String> risultato = Query.stampaAppunti();
				if(risultato.size() > 1)
					for(String g : risultato)
						result.append(g);
				else 
					JOptionPane.showMessageDialog(null, "Non ci sono appunti", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa tutte le video-lezioni, tranne dei tutor che insegnano una determinata materia")) {
				String materia = JOptionPane.showInputDialog("Inserisci la materia");
				ArrayList<String> risultato = Query.stampaVideolezioniTranneTutor(materia);
				if(materia.equals(null))
					;
				else if(risultato.size() > 1)
					for(String g : risultato)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono videolezioni", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa tutti gli appunti con prezzo inferiore ad una determinata cifra")) {
				float prezzo = Float.parseFloat(JOptionPane.showInputDialog("Inserisci il prezzo"));
				ArrayList<String> risultato = Query.stampaAppuntiPrezzo(prezzo);
				if(risultato.size() > 1)
					for(String g : risultato)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono appunti con prezzo minore di: " + prezzo, "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa del codice di tutti gli acquisti di appunti che non sono in formato digitale, la cui spedizione è gratis")) {
				ArrayList<String> risultato = Query.stampaCodiceSpedizione();
				if(risultato.size() > 1)
					for(String g : risultato)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono transazioni che riguardino appunti cartacei con spedizione gratuita", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa dei moderatori")) {
				ArrayList<String> result1 = Query.StampaStaffModeratore();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono moderatori", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa dei tutor")) {
				ArrayList<String> result1 = Query.StampaStaffTutor();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono tutor", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa degli account")) {
				ArrayList<String> result1 = Query.StampaAccount();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono membri dello staff", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa degli acquirenti")) {
				ArrayList<String> result1 = Query.StampaAccountAcquirente();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono acquirenti", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa dei venditori")) {
				ArrayList<String> result1 = Query.StampaAccountVenditore();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono venditori", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa degli appunti digitali")) {
				ArrayList<String> result1 = Query.stampaAppuntiDigitali();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono appunti digitali", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa degli appunti cartacei")) {
				ArrayList<String> result1 = Query.stampaAppuntiCartacei();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono appunti cartacei", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa numero acquisti di un account acquirente che ha effettuato almeno un acquisto")) {
				String username = JOptionPane.showInputDialog("Inserisci l'username di un acquirente");
				ArrayList<String> result1 = Query.stampaNumAcquisti(username);
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "L'utente non ha effettuato nessun acquisto", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.contentEquals("Stampa la lista di Tutor il cui cognome inizia con una data lettera o stringa")) {
				String lettere = JOptionPane.showInputDialog("Inserisci una lettera o una stringa");
				ArrayList<String> result1 = Query.stampaTutorLettera(lettere);
				if(result1.size() > 2)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono tutor che iniziano con " + lettere, "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa l’appunto con il maggior prezzo")) {
				ArrayList<String> result1 = Query.stampaMaxPrezzo();
				if(result1.size() > 1)
					for(String g : result1)
						result.append(g);
				else
					JOptionPane.showMessageDialog(null, "Non ci sono appunti", "Errore", JOptionPane.ERROR_MESSAGE);
			} else if(selected.equals("Stampa gli acquisti in un determinato intervallo")) {
                setVisible(false);
                JFrame frame = new JFrame();
                frame.setTitle("Inserisci l'intervallo di date");

                JLabel dataI = new JLabel("Data di inizio: ");
                JTextField dataInizio = new JTextField();
                JLabel dataF = new JLabel("Data fine: ");
                JTextField dataFine = new JTextField();

                JPanel pannello = new JPanel(new GridLayout(3, 2));
                pannello.add(dataI);
                pannello.add(dataInizio);
                pannello.add(dataF);
                pannello.add(dataFine);

                JButton vai = new JButton("Stampa");
                vai.addActionListener(d -> {
                    ArrayList <String> result1 = Query.AcquistiIntervalloDate(Date.valueOf(dataInizio.getText()), Date.valueOf(dataFine.getText()));
                    if(result1.size() > 1)
                        for(String g : result1)
                            result.append(g);
                    else
                        JOptionPane.showMessageDialog(null, "Non ci sono acquisti compresi da " + dataInizio.getText() + " a " + dataFine.getText());
                    frame.dispose();
                    setVisible(true);
                });

                JButton back = new JButton("Indietro");
                back.addActionListener(d -> {
                    frame.dispose();
                    setVisible(true);
                });

                pannello.add(vai);
                pannello.add(back);

                frame.add(pannello);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(300, 150);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);

            } else if(selected.equals("Inserimento di un numero di telefono di un account")) {
            	setVisible(false);
            	JFrame frame = new JFrame();
            	frame.setTitle("Inserimento di un numero di telefono di un account");
            	
            	JLabel numeroTelefono = new JLabel("Numero di telefono: ");
            	JTextField numeroTelefonoArea = new JTextField();
            	JLabel username = new JLabel("Username: ");
            	JTextField usernameArea = new JTextField();
            	
            	JPanel pannello = new JPanel();
            	pannello.setLayout(new GridLayout(3, 1));
            	pannello.add(numeroTelefono);
            	pannello.add(numeroTelefonoArea);
            	pannello.add(username);
            	pannello.add(usernameArea);
            	
            	
            	JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(l -> {
					if(Query.InserisciNumeroAccount(Long.parseLong(numeroTelefonoArea.getText()), usernameArea.getText())) {
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				
            	frame.add(pannello);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(300, 150);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            } else if(selected.equals("Inserimento di un numero di telefono di un membro dello staff")) {
            	setVisible(false);
            	JFrame frame = new JFrame();
            	frame.setTitle("Inserimento di un numero di telefono di un membro dello staff");
            	
            	JLabel numeroTelefono = new JLabel("Numero di telefono: ");
            	JTextField numeroTelefonoArea = new JTextField();
            	JLabel codiceFiscale = new JLabel("Codice fiscale: ");
            	JTextField codiceFiscaleArea = new JTextField();
            	
            	JPanel pannello = new JPanel();
            	pannello.setLayout(new GridLayout(3, 1));
            	pannello.add(numeroTelefono);
            	pannello.add(numeroTelefonoArea);
            	pannello.add(codiceFiscale);
            	pannello.add(codiceFiscaleArea);
            	
            	
            	JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(l -> {
					if(Query.InserisciNumeroStaff(Long.parseLong(numeroTelefonoArea.getText()), codiceFiscaleArea.getText())) {
						frame.dispose();
						setVisible(true);
						JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
						} else ;
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				
            	frame.add(pannello);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(300, 150);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            } else if(selected.equals("Inserimento di una specializzazione di un tutor")) {
            	setVisible(false);
            	
            	Object[] options = { "Esistente", "Non esistente"};
				int res = JOptionPane.showOptionDialog(getParent(), "La materia esiste già?", "Materia", JOptionPane.NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, null);
            	
				JFrame frame = new JFrame();
            	frame.setTitle("Inserimento di una specializzazione di un tutor");
            	
            	JLabel materia = new JLabel("Materia: ");
            	JTextField materiaArea = new JTextField();
            	JLabel codiceFiscale = new JLabel("Codice fiscale: ");
            	JTextField codiceFiscaleArea = new JTextField();
            	
            	JPanel pannello = new JPanel();
            	pannello.setLayout(new GridLayout(3, 1));
            	pannello.add(materia);
            	pannello.add(materiaArea);
            	pannello.add(codiceFiscale);
            	pannello.add(codiceFiscaleArea);
            	
            	
            	JButton esegui1 = new JButton("Esegui");
				esegui1.addActionListener(l -> {
					if(res == 1) {
						if(Query.InserisciTutorSpecializzazioneNuova(materiaArea.getText(), codiceFiscaleArea.getText())){
							frame.dispose();
							setVisible(true);
							JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
							} else ;
					} else if(res == 0) {
						if(Query.InserisciTutorSpecializzazioneEsistente(materiaArea.getText(), codiceFiscaleArea.getText())){
							frame.dispose();
							setVisible(true);
							JOptionPane.showMessageDialog(frame, "Operazione eseguita con successo");
							} else ;
					}
				});
				
				JButton back = new JButton("Indietro");
				back.addActionListener(d -> {
					frame.dispose();
					setVisible(true);
				});
				
				pannello.add(esegui1);
				pannello.add(back);
				
            	frame.add(pannello);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(300, 150);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
			
		});
		
		JButton clear1 = new JButton("Clear");
		clear1.addActionListener(e -> {
			result.setText(" ");
		});
		
		JLabel queryLabel = new JLabel("Query:");
		
		pannelloQuery.add(clear1);
		pannelloQuery.add(queryLabel);
		pannelloQuery.add(query);
		pannelloQuery.add(esegui);
		pannelloQuery.add(disconnect);
		
		this.add(pannelloQuery, BorderLayout.SOUTH);
		
		setSize(1200, 800);
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
		JLabel username = new JLabel("Username:");
		JLabel password = new JLabel("Password:");
		
		JButton connect = new JButton("Connetti");
		connect.addActionListener(l -> {
			if(Query.connect(usernameArea.getText(), passwordArea.getText())) {
				JOptionPane.showMessageDialog(null, "Connessione riuscita!");
				@SuppressWarnings("unused")
				Gui gui = new Gui();
				//Query.ControlloCarte(date.getDayOfMonth());
				framePannello.setVisible(false);
			} else {
				JOptionPane.showMessageDialog(null, "Connessione non riuscita.");
			}
		});
		
		
		JCheckBox select = new JCheckBox("Show password");
		select.addActionListener(l -> {
			if(select.isSelected())
				passwordArea.setEchoChar((char) 0);
		});
		
		ImageIcon immagine = new ImageIcon("src/image/NoteMarket.png");
		JLabel contenitoreImmagine = new JLabel(immagine, JLabel.CENTER);
		
		JPanel pannello = new JPanel();
		
		passwordArea.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent event) {
				if(event.getKeyCode() == KeyEvent.VK_ENTER)
					connect.doClick();
			}
		});
		
		pannello.setLayout(new GridLayout(3,1));
		pannello.setBorder(BorderFactory.createTitledBorder("Accesso"));
		pannello.add(username);
		pannello.add(usernameArea);
		pannello.add(password);
		pannello.add(passwordArea);
		pannello.add(select);
		pannello.add(connect);
		
		framePannello.add(pannello, BorderLayout.CENTER);
		framePannello.add(contenitoreImmagine, BorderLayout.NORTH);
		
		framePannello.setTitle("Pannello di controllo");
		framePannello.setVisible(true);
		framePannello.setLocationRelativeTo(null);
		framePannello.setSize(300, 350);
		framePannello.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		
	}

}
